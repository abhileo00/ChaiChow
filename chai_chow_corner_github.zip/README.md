# Chai Chow Corner

A simple Streamlit-based food ordering and inventory web app.

## Features
- Admin, Staff, and Customer login
- Feedback collection
- Customer registration with approval flow
- Future support for Orders, Inventory, Reports

## Setup
```bash
pip install -r requirements.txt
streamlit run main.py
```

## Data
All data is stored in CSV files inside the `/data` folder.
