"""
Chai Chow Corner – Streamlit Web App
Author: Your Name
Repo: github.com/yourusername/chai-chow-corner
"""

import streamlit as st
import pandas as pd
import os
from datetime import datetime

# ------------------------------
# CONFIGURATION & SETUP
# ------------------------------
st.set_page_config(page_title="Chai Chow Corner", layout="wide", initial_sidebar_state="collapsed")

# Brand Name
BRAND_NAME = "Chai Chow Corner"

# Data Folder Setup
DATA_FOLDER = "data"
os.makedirs(DATA_FOLDER, exist_ok=True)

# CSV File Paths
USER_FILE = os.path.join(DATA_FOLDER, "users.csv")
ORDER_FILE = os.path.join(DATA_FOLDER, "orders.csv")
MENU_FILE = os.path.join(DATA_FOLDER, "menu.csv")
INVENTORY_FILE = os.path.join(DATA_FOLDER, "inventory.csv")
FEEDBACK_FILE = os.path.join(DATA_FOLDER, "feedback.csv")

# ------------------------------
# UTILITY FUNCTIONS
# ------------------------------
def load_csv(file, columns):
    if not os.path.exists(file):
        pd.DataFrame(columns=columns).to_csv(file, index=False)
    return pd.read_csv(file)

def save_csv(df, file):
    df.to_csv(file, index=False)

def generate_id(prefix):
    return prefix + datetime.now().strftime("%Y%m%d%H%M%S")

def get_today_str():
    return datetime.now().strftime("%Y-%m-%d")

# ------------------------------
# SESSION STATE INITIALIZATION
# ------------------------------
if 'role' not in st.session_state:
    st.session_state['role'] = None
if 'user' not in st.session_state:
    st.session_state['user'] = None

# ------------------------------
# LOGIN PAGE
# ------------------------------
def login_page():
    st.title(f"👋 Welcome to {BRAND_NAME}")
    st.subheader("Login")

    users = load_csv(USER_FILE, ["id", "role", "full_name", "email", "mobile", "password", "status", "created_by", "created_at"])

    role = st.selectbox("Login as", ["Customer", "Staff", "Admin"])

    if role == "Admin":
        email = st.text_input("Admin Email")
    else:
        mobile = st.text_input("Mobile Number")

    password = st.text_input("Password", type="password")

    if st.button("Login"):
        if role == "Admin":
            user_row = users[(users["role"] == "Admin") & (users["email"] == email) & (users["password"] == password)]
        else:
            user_row = users[(users["role"] == role) & (users["mobile"] == mobile) & (users["password"] == password)]

        if not user_row.empty and user_row.iloc[0]["status"] == "Active":
            st.success("Login successful!")
            st.session_state['role'] = user_row.iloc[0]["role"]
            st.session_state['user'] = user_row.iloc[0].to_dict()
            st.experimental_rerun()
        else:
            st.error("Invalid credentials or inactive account.")

    st.markdown("---")
    if role == "Customer":
        st.subheader("New Customer? Register Below")
        with st.form("register_form"):
            full_name = st.text_input("Full Name")
            mobile = st.text_input("Mobile Number")
            reg_email = st.text_input("Email Address (optional)")
            reg_password = st.text_input("Create Password")
            confirm_password = st.text_input("Confirm Password")
            submitted = st.form_submit_button("Register")

            if submitted:
                if reg_password != confirm_password:
                    st.error("Passwords do not match.")
                elif users["mobile"].astype(str).str.contains(mobile).any():
                    st.error("Mobile number already registered.")
                else:
                    new_user = {
                        "id": generate_id("USR"),
                        "role": "Customer",
                        "full_name": full_name,
                        "email": reg_email,
                        "mobile": mobile,
                        "password": reg_password,
                        "status": "Pending",
                        "created_by": "Self",
                        "created_at": get_today_str()
                    }
                    users = users.append(new_user, ignore_index=True)
                    save_csv(users, USER_FILE)
                    st.success("Registration submitted. Wait for admin approval.")

# ------------------------------
# FEEDBACK PAGE
# ------------------------------
def feedback_page():
    st.title("💬 Feedback - Help Improve Our Service")

    with st.form("feedback_form"):
        name = st.text_input("Your Name (optional)")
        contact = st.text_input("Contact Info (email or mobile)")
        feedback_type = st.selectbox("Are you a:", ["Walk-in", "Registered"])
        rating = st.slider("Rate Us (1 - Poor to 5 - Excellent)", 1, 5, 5)
        comments = st.text_area("Your Feedback")

        submitted = st.form_submit_button("Submit Feedback")
        if submitted:
            feedback_df = load_csv(FEEDBACK_FILE, ["name", "contact", "feedback_type", "rating", "comments", "submitted_at"])
            feedback_df = feedback_df.append({
                "name": name,
                "contact": contact,
                "feedback_type": feedback_type,
                "rating": rating,
                "comments": comments,
                "submitted_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }, ignore_index=True)
            save_csv(feedback_df, FEEDBACK_FILE)
            st.success("Thanks for your feedback!")

# ------------------------------
# MAIN NAVIGATION
# ------------------------------
def main():
    pages = {
        "Login": login_page,
        "Feedback": feedback_page
        # More modules (Orders, Menu, Inventory, Reports) will go here
    }

    if st.session_state['role']:
        selected = st.selectbox("🔰 Navigate", list(pages.keys()))
        pages[selected]()
    else:
        login_page()

# ------------------------------
# ENTRY POINT
# ------------------------------
if __name__ == "__main__":
    main()
